## Changelog

- Added updateJson
- Added changelog.md
- Fixed script permissions error and update to latest version from v2.0 to v3.0.
- Fixed Failed FPS on ML script and some changes on script.
- Removed ML Unlocker script v2.0 and replaced a new script v3.0.
