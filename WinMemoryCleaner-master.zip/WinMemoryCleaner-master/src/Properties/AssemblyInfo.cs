﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Windows;
using WinMemoryCleaner;

[assembly: AssemblyCompany(Constants.App.Author.Name)]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright(Constants.App.License)]
[assembly: AssemblyCulture("")]
[assembly: AssemblyDescription(Constants.App.Title)]
[assembly: AssemblyFileVersion("2.8.0.0")]
[assembly: AssemblyKeyFile(Constants.App.KeyFile)]
[assembly: AssemblyProduct(Constants.App.Name)]
[assembly: AssemblyTitle(Constants.App.Title)]
[assembly: AssemblyTrademark(Constants.App.Author.Name)]
[assembly: AssemblyVersion("2.8.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid(Constants.App.Id)]
[assembly: NeutralResourcesLanguage("")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.None)]
